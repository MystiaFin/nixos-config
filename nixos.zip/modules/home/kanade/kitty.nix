let
  settings = {
    font_family = "JetBrainsMono Nerd Font";
    font_size = 13;

    background_opacity = "0.92";
    window_padding_width = 8;
    cursor_blink_interval = 0;
    tab_bar_style = "powerline";
    tab_powerline_style = "slanted";
    scrollback_lines = 10000;
    enable_audio_bell = false;
    confirm_os_window_close = 0;

    background = "#1e1e2e";
    foreground = "#cdd6f4";
    selection_background = "#585b70";
    selection_foreground = "#cdd6f4";
    url_color = "#89b4fa";
    cursor = "#f5e0dc";
    cursor_text_color = "#1e1e2e";

    active_border_color = "#cba6f7";
    inactive_border_color = "#313244";
    bell_border_color = "#f9e2af";

    active_tab_background = "#cba6f7";
    active_tab_foreground = "#1e1e2e";
    inactive_tab_background = "#313244";
    inactive_tab_foreground = "#cdd6f4";

    color0  = "#45475a";
    color8  = "#585b70";
    color1  = "#f38ba8";
    color9  = "#f38ba8";
    color2  = "#a6e3a1";
    color10 = "#a6e3a1";
    color3  = "#f9e2af";
    color11 = "#f9e2af";
    color4  = "#89b4fa";
    color12 = "#89b4fa";
    color5  = "#f5c2e7";
    color13 = "#f5c2e7";
    color6  = "#94e2d5";
    color14 = "#94e2d5";
    color7  = "#bac2de";
    color15 = "#a6adc8";

    cursor_shape = "block";
    shell_integration = "no-cursor";
  };

  mkKittyConf = attrs:
    let
      toStr = v:
        if builtins.isBool v then (if v then "yes" else "no")
        else toString v;
      lines = builtins.map (key: "${key} ${toStr attrs.${key}}") (builtins.attrNames attrs);
    in builtins.concatStringsSep "\n" lines;
in {
  xdg.configFile."kitty/kitty.conf".text = mkKittyConf settings;
}
