{
  xdg.configFile."fontconfig/fonts.conf".text = ''
    <?xml version='1.0'?>
    <!DOCTYPE fontconfig SYSTEM 'fonts.dtd'>
    <fontconfig>
     <match target="font">
      <edit mode="assign" name="hinting">
       <bool>false</bool>
      </edit>
     </match>

     <match target="font">
      <edit mode="assign" name="hintstyle">
       <const>hintslight</const>
      </edit>
     </match>

     <match target="font">
      <edit mode="assign" name="rgba">
       <const>rgb</const>
      </edit>
     </match>
     <match target="font">
      <edit mode="assign" name="antialias">
       <bool>true</bool>
      </edit>
     </match>
     <match target="font">
      <edit mode="assign" name="lcdfilter">
       <const>lcddefault</const>
      </edit>
     </match>
    </fontconfig>
  '';
}
